#include "AMBIT.h"
#include "main.h"

array<SESSION, MAX_USER + NUM_NPC> clients;
HANDLE g_h_iocp;
SOCKET g_s_socket;

//#define STRESSTEST

concurrent_unordered_map<int, concurrent_unordered_map<int, concurrent_unordered_map<int, bool>>> sectors;

void error_display(const char* msg, int err_no)
{
	WCHAR* lpMsgBuf;
	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER |
		FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, err_no,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR)&lpMsgBuf, 0, NULL);
	std::cout << msg;
	std::wcout << L"���� " << lpMsgBuf << std::endl;
	while (true);
	LocalFree(lpMsgBuf);
}

int distance_cell(int a, int b)
{
	return abs(clients[a].X() - clients[b].X()) + abs(clients[a].Y() - clients[b].Y());
}

int get_new_client_id()
{
	for (int i = 0; i < MAX_USER; ++i)
	{
		clients[i]._sl.lock();
		if (clients[i]._s_state == ST_FREE)
		{
			clients[i]._s_state = ST_ACCEPTED;
			clients[i]._sl.unlock();
			return i;
		}
		clients[i]._sl.unlock();
	}
	return -1;
}

void disconnect(int c_id)
{
	clients[c_id]._sl.lock();
	if (clients[c_id]._s_state == ST_FREE)
	{
		clients[c_id]._sl.unlock();
		return;
	}
	closesocket(clients[c_id]._socket);
	clients[c_id]._s_state = ST_FREE;
	DataBaseManager::addDBEvent(c_id, DB_EV_LOGOUT, clients[c_id].getData());

	auto l = clients[c_id].view_list;
	clients[c_id]._sl.unlock();

	for (auto& pl : l)
	{
		if (pl == c_id) continue;
		if (pl >= MAX_USER) continue;
		clients[pl]._sl.lock();
		if (clients[pl]._s_state != ST_INGAME)
		{
			clients[pl]._sl.unlock();
			continue;
		} //�б⸸ �ϴµ���?
		//���� �۾��� ������ �Ǵ� �������ݾ�

		clients[pl].vl.lock();
		if (0 != clients[pl].view_list.count(c_id))
		{
			clients[pl].view_list.erase(c_id);
			clients[pl].vl.unlock();
			clients[pl].send_remove_packet(c_id);
		}
		else
			clients[pl].vl.unlock();

		clients[pl]._sl.unlock();
	}

}

void process_packet(int c_id, char* packet)
{
	switch (packet[1])
	{
	case CS_LOGIN:
	{
		clients[c_id].tl.lock();
		clients[c_id].last_act_time = chrono::system_clock::now();
		clients[c_id].tl.unlock();
		CS_LOGIN_PACKET* p = reinterpret_cast<CS_LOGIN_PACKET*>(packet);

		clients[c_id]._sl.lock();
		if (clients[c_id]._s_state == ST_FREE)
		{
			clients[c_id]._sl.unlock();
			break;
		}
		if (clients[c_id]._s_state == ST_INGAME)
		{
			clients[c_id].send_login_fail_packet(1);
			clients[c_id]._sl.unlock();
			disconnect(c_id);
			break;
		}
		if (strcmp(p->name, "ERRORNAME") == 0 || strcmp(p->pass, "ERRORNAME") == 0)
		{
			clients[c_id].send_login_fail_packet(0);
			clients[c_id]._sl.unlock();
			disconnect(c_id);
		}

		//DB ������
		LoginData dbTMP;
		strcpy(dbTMP.name, p->name);
		strcpy(dbTMP.pass, p->pass);

		if (p->isNewUser)
		{
			DataBaseManager::addDBEvent(c_id, DB_EV_NEWUSER, dbTMP);
		}
		else
		{
			DataBaseManager::addDBEvent(c_id, DB_EV_LOGIN, dbTMP);
		}

		clients[c_id].dir = 0;
		clients[c_id]._sl.unlock();

		break;
	}
	case CS_ATTACK:
	{
		if (c_id < MAX_USER)
		{
			clients[c_id].tl.lock();
			if (clients[c_id].last_act_time + chrono::milliseconds(500) > chrono::system_clock::now())
			{
				clients[c_id].tl.unlock();
				break;
			}
		}
		clients[c_id].last_act_time = chrono::system_clock::now();
		clients[c_id].tl.unlock();
		CS_ATTACK_PACKET* p = reinterpret_cast<CS_ATTACK_PACKET*>(packet);
		//
		std::vector<COORD> range;
		range.reserve(10);
		switch (p->skilltype)
		{
		case 0:
			range.emplace_back(1, 0);
			range.emplace_back(0, 1);
			range.emplace_back(0, -1);
			range.emplace_back(-1, 0);
			break;
		case 1:
			switch (clients[c_id].dir)
			{
			case 0:
				range.emplace_back(0, -1);
				range.emplace_back(0, -2);
				range.emplace_back(0, -3);
				break;
			case 1:
				range.emplace_back(0, 1);
				range.emplace_back(0, 2);
				range.emplace_back(0, 3);
				break;
			case 2:
				range.emplace_back(-1,0);
				range.emplace_back(-2,0);
				range.emplace_back(-3,0);
				break;
			case 3:
				range.emplace_back(1, 0);
				range.emplace_back(2, 0);
				range.emplace_back(3, 0);
				break;
			}
			break;
		case 2:
		{
			int heal = -1 * ((rand() % 5) + 5);
			clients[c_id]._sl.lock();
			clients[c_id].setDamage(heal);
			clients[c_id]._sl.unlock();

			string mess;
			mess = clients[c_id].getData().name;
			mess += " heal ";
			mess += to_string(heal);
			mess += " HP!";
			clients[c_id].send_chat_packet(-1, mess.c_str());
			return;
			break;
		}
		}

		clients[c_id].vl.lock();
		unordered_set<int> r_view_list = clients[c_id].view_list;
		clients[c_id].vl.unlock();

		for (auto& pln : r_view_list)
		{
			//cout << "\nGET";
			if (clients[c_id].getData().isPlayer == clients[pln].getData().isPlayer)
				continue;

			int hitted = 0;

			auto& pl = clients[pln];

			for (auto cd : range)
			{
				if (pl.X() == clients[c_id].X() + cd.X && pl.Y() == clients[c_id].Y() + cd.Y)
				{
					if (pl._s_state != ST_NPC_DEAD)
					{
						//�ǰ�
						//cout << "\nHITTED";
						hitted = rand() % 5 + clients[c_id].getData().level;
						if (p->skilltype == 1)
							hitted = 50;
						pl._sl.lock();
						pl.setDamage(hitted);
						pl._sl.unlock();
						break;
					}
				}
			}

			if (hitted > 0)
			{
				string mess;
				mess = clients[c_id].getData().name;
				mess += " attack ";
				mess += pl.getData().name;
				mess += " by ";
				mess += to_string(hitted);
				clients[c_id].send_chat_packet(-1, mess.c_str());
				clients[c_id].send_stat_change_packet(pln);
				for (auto& every : r_view_list)
				{
					if (!clients[every].getData().isPlayer)
						continue;

					clients[every].send_stat_change_packet(pln);
				}
			}
			else if (hitted < 0)
			{
				clients[c_id]._sl.lock();
				bool levelup = clients[c_id].appendEXP((pl.getData().level + 3) * pl.getData().level * 2);
				clients[c_id]._sl.unlock();

				string mess;
				mess = pl.getData().name;
				mess += " collapsed!";
				clients[c_id].send_chat_packet(-1, mess.c_str());
				mess = to_string((pl.getData().level + 3) * pl.getData().level * 2);
				mess += " EXP Gained!";
				clients[c_id].send_chat_packet(-1, mess.c_str());
				clients[c_id].send_stat_change_packet(c_id);
				clients[c_id].send_remove_packet(pln);
				clients[c_id].vl.lock();
				clients[c_id].view_list.erase(pln);
				clients[c_id].vl.unlock();
				for (auto& every : r_view_list)
				{
					if (!clients[every].getData().isPlayer)
						continue;

					clients[every].send_stat_change_packet(c_id);
					clients[every].send_remove_packet(pln);
					clients[every].vl.lock();
					clients[every].view_list.erase(pln);
					clients[every].vl.unlock();

					if (levelup)
					{
						string lmess;
						lmess = clients[c_id].getData().name;
						lmess += " level up to ";
						lmess += clients[c_id].getData().level;
						clients[every].send_chat_packet(-1, lmess.c_str());
					}
				}
			}
		}

		break;
	}
	case CS_MOVE:
	{
		if (c_id < MAX_USER)
		{
			clients[c_id].tl.lock();
			if (clients[c_id].last_act_time + chrono::milliseconds(500) > chrono::system_clock::now())
			{
				clients[c_id].tl.unlock();
				break;
			}
		}
		clients[c_id].last_act_time = chrono::system_clock::now();
		clients[c_id].tl.unlock();
		CS_MOVE_PACKET* p = reinterpret_cast<CS_MOVE_PACKET*>(packet);

		short x = clients[c_id].X();
		short y = clients[c_id].Y();

		switch (p->direction)
		{
		case 0:
			if (y > 0 && s_Map::canMove(x, y - 1))
			{
				y--;
				clients[c_id].dir = 0;
			}
			break;
		case 1:
			if (y < W_HEIGHT - 1 && s_Map::canMove(x, y + 1))
			{
				y++;
				clients[c_id].dir = 1;
			}
			break;
		case 2:
			if (x > 0 && s_Map::canMove(x - 1, y))
			{
				x--;
				clients[c_id].dir = 2;
			}
			break;
		case 3:
			if (x < W_WIDTH - 1 && s_Map::canMove(x + 1, y))
			{
				x++;
				clients[c_id].dir = 3;
			}
			break;
		}

		clients[c_id].setXY(x, y);


		//-> ���� ���� ��� Ŭ���̾�Ʈ���� (�ڽ� ����)
		for (int i = 0; i < 3; ++i)
		{
			for (int h = 0; h < 3; ++h)
			{
				if (clients[c_id].sectorX - 1 + i < 0 ||
					clients[c_id].sectorX - 1 + i >= W_WIDTH / SECTOR_WIDTH ||
					clients[c_id].sectorY - 1 + h < 0 ||
					clients[c_id].sectorY - 1 + h >= W_HEIGHT / SECTOR_HEIGHT)
					continue;

				for (auto& pln : sectors[clients[c_id].sectorX - 1 + i][clients[c_id].sectorY - 1 + h])
				{
					if (pln.second == false)
						continue;
					if (pln.first == c_id)
					{
						clients[c_id].send_move_packet(c_id, p->client_time);
						continue;
					}

					auto& pl = clients[pln.first];

					//���� ���� NPC �����
					if (pl._s_state == ST_NPC_SLEEP)
					{
						SESSION_STATE sst = ST_NPC_SLEEP;
						if (atomic_compare_exchange_weak(&(pl._s_state), &sst, ST_INGAME))
						{
							HeartManager::add_timer(pl.npc_id, 1000, EV_MOVE, c_id);
						}
					}

					pl._sl.lock();
					if (pl.ID() >= MAX_USER)
					{
						pl._sl.unlock();
						continue;
					}
					if (pl._s_state != ST_INGAME)
					{
						pl._sl.unlock();
						continue;
					}

					//near�� ��� ��ü�� ����?
					if (distance_cell(c_id, pl.ID()) <= RANGE)
					{
						clients[c_id].vl.lock();
						//������
						if (!clients[c_id].view_list.contains(pl.ID()))
						{
							clients[c_id].view_list.insert(pl.ID());
							clients[c_id].vl.unlock();

							//put
							clients[c_id].send_put_packet(pl.ID());


							//���� ������� ������
							pl.vl.lock();
							if (!pl.view_list.contains(clients[c_id].ID()))
							{
								pl.view_list.insert(clients[c_id].ID());
								pl.vl.unlock();

								//put
								pl.send_put_packet(c_id);
							}
							else
							{
								pl.vl.unlock();

								//move
								pl.send_move_packet(c_id, p->client_time);
							}
						}
						else // ������
						{
							clients[c_id].vl.unlock();

							//���� ������� ������
							pl.vl.lock();
							if (!pl.view_list.contains(clients[c_id].ID()))
							{
								pl.view_list.insert(clients[c_id].ID());
								pl.vl.unlock();

								//put
								pl.send_put_packet(c_id);
							}
							else
							{
								pl.vl.unlock();

								//move
								pl.send_move_packet(c_id, p->client_time);
							}
						}
					}
					pl._sl.unlock();
				}
			}
		}

		//-----------

		clients[c_id].vl.lock();
		unordered_set<int> r_view_list = clients[c_id].view_list;
		clients[c_id].vl.unlock();

		for (auto ids : r_view_list)
		{
			if (distance_cell(ids, c_id) > RANGE)
			{
				clients[c_id].vl.lock();
				clients[c_id].view_list.erase(ids);
				clients[c_id].vl.unlock();

				//remove
				clients[c_id].send_remove_packet(ids);

				clients[ids].vl.lock();
				if (clients[ids].view_list.find(c_id) != clients[ids].view_list.end())
				{
					clients[ids].view_list.erase(c_id);
					clients[ids].vl.unlock();

					//remove
					clients[ids].send_remove_packet(c_id);
				}
				else
				{
					clients[ids].vl.unlock();
				}
			}
		}

		break;
	}
	case CS_CHAT:
	{
		CS_CHAT_PACKET* p = reinterpret_cast<CS_CHAT_PACKET*>(packet);


		for (int i = 0; i < 3; ++i)
		{
			for (int h = 0; h < 3; ++h)
			{
				if (clients[c_id].sectorX - 1 + i < 0 ||
					clients[c_id].sectorX - 1 + i >= W_WIDTH / SECTOR_WIDTH ||
					clients[c_id].sectorY - 1 + h < 0 ||
					clients[c_id].sectorY - 1 + h >= W_HEIGHT / SECTOR_HEIGHT)
					continue;

				for (auto& pln : sectors[clients[c_id].sectorX - 1 + i][clients[c_id].sectorY - 1 + h])
				{
					if (pln.second)
					{
						if (pln.first < MAX_USER)
							clients[pln.first].send_chat_packet(c_id, p->mess);
					}
				}
			}
		}

		break;
	}
	}

}

void do_worker()
{

	while (true)
	{
		DWORD num_bytes;
		ULONG_PTR key;
		WSAOVERLAPPED* over;
		BOOL ret = GetQueuedCompletionStatus(g_h_iocp, &num_bytes, &key, &over, INFINITE);
		OVER_EXP* ex_over = reinterpret_cast<OVER_EXP*>(over);

		if (FALSE == ret)
		{
			if (ex_over->_comp_type == OP_ACCEPT) cout << "Accept ERROR";
			else
			{
				cout << "GQCS error on client[" << key << "]\n";
				disconnect(static_cast<int>(key));
				if (ex_over->_comp_type == OP_SEND) delete ex_over;
				continue;
			}
		}

		switch (ex_over->_comp_type)
		{
		case OP_ACCEPT:
		{
			SOCKET c_socket = reinterpret_cast<SOCKET>(ex_over->_wsabuf.buf);
			int client_id = get_new_client_id();
			if (client_id != -1)
			{

				//printf("Login : %d\n", client_id);
				clients[client_id].ID(1);
				clients[client_id].setXY(0, 0);
				sprintf(clients[client_id].NAME(), "tmp");
				clients[client_id]._socket = c_socket;
				clients[client_id]._prev_remain = 0;
				CreateIoCompletionPort(reinterpret_cast<HANDLE>(c_socket), g_h_iocp, client_id, 0);

				clients[client_id].do_recv();
				c_socket = WSASocket(AF_INET, SOCK_STREAM, 0, NULL, 0, WSA_FLAG_OVERLAPPED);
			}
			else
			{
				clients[client_id].send_login_fail_packet(2);
				cout << "Max user exceeded.\n";
			}
			ZeroMemory(&ex_over->_over, sizeof(ex_over->_over));
			ex_over->_wsabuf.buf = reinterpret_cast<CHAR*>(c_socket);
			int addr_size = sizeof(SOCKADDR_IN);
			AcceptEx(g_s_socket, c_socket, ex_over->_send_buf, 0, addr_size + 16, addr_size + 16, 0, &ex_over->_over);
			break;
		}
		case OP_RECV:
		{
			if (0 == num_bytes)
			{
				disconnect(key);
			}
			clients[key]._prev_remain += num_bytes;

			char* p = ex_over->_send_buf;
			vector<char*> packets;
			packets.reserve(3);
			do
			{
				int packet_size = p[0];
				if (packet_size <= clients[key]._prev_remain)
				{
					packets.push_back(p);
					p = p + packet_size;
					clients[key]._prev_remain -= packet_size;
				}
			} while (clients[key]._prev_remain > 0);
			for (auto& pp : packets)
			{
				process_packet(key, pp);
			}
			if (clients[key]._prev_remain > 0)
			{
				memcpy(ex_over->_send_buf, p, clients[key]._prev_remain);
			}

			clients[key].do_recv();
			break;
		}
		case OP_SEND:
			if (0 == num_bytes)
			{
				disconnect(key);
			}
			delete ex_over;
			break;

		case OP_DB:
		{
			OVER_DB* db_over = reinterpret_cast<OVER_DB*>(ex_over);
			switch (db_over->_db_type)
			{
			case DB_EV_LOGIN:
			{
				LoginData Data = db_over->datas;
				int c_id = key;
				Data.sc_id = c_id;

#ifndef STRESSTEST
				for (int i = 0; i < MAX_USER; ++i)
				{
					clients[i]._sl.lock();
					if (clients[i]._s_state != ST_FREE)
					{
						if (strcmp(clients[i].getData().id, Data.id) == 0)
						{
							Data.isValidLogin = false;
						}
					}
					clients[i]._sl.unlock();
				}
#endif

				clients[c_id]._sl.lock();
				clients[c_id].setData(Data);
				clients[c_id].send_login_info_packet();

				if (!Data.isValidLogin)
				{
					//cout << "This is Not ValidLogin";
					clients[c_id]._sl.unlock();
					disconnect(c_id);
					break;
				}
				else
				{
					//cout << "Login Success : " << Data.name;
					clients[c_id]._s_state = ST_INGAME;
					clients[c_id]._sl.unlock();

					//-> ���� ���� ��� Ŭ���̾�Ʈ���� (�ڽ� ����)
					for (int i = 0; i < 3; ++i)
					{
						for (int h = 0; h < 3; ++h)
						{
							if (clients[c_id].sectorX - 1 + i < 0 ||
								clients[c_id].sectorX - 1 + i >= W_WIDTH / SECTOR_WIDTH ||
								clients[c_id].sectorY - 1 + h < 0 ||
								clients[c_id].sectorY - 1 + h >= W_HEIGHT / SECTOR_HEIGHT)
								continue;

							for (auto& pln : sectors[clients[c_id].sectorX - 1 + i][clients[c_id].sectorY - 1 + h])
							{
								if (pln.second == false)
									continue;
								if (pln.first == c_id)
								{
									clients[c_id].send_move_packet(c_id, 0);
									continue;
								}

								auto& pl = clients[pln.first];

								//���� ���� NPC �����
								if (pl._s_state == ST_NPC_SLEEP)
								{
									SESSION_STATE sst = ST_NPC_SLEEP;
									if (atomic_compare_exchange_weak(&(pl._s_state), &sst, ST_INGAME))
									{
										HeartManager::add_timer(pl.npc_id, 1000, EV_MOVE, c_id);
									}
								}

								pl._sl.lock();
								if (pl.ID() >= MAX_USER)
								{
									pl._sl.unlock();
									continue;
								}

								if (pl._s_state != ST_INGAME)
								{
									pl._sl.unlock();
									continue;
								}

								//near�� ��� ��ü�� ����?
								if (distance_cell(c_id, pl.ID()) <= RANGE)
								{
									clients[c_id].vl.lock();
									//������
									if (!clients[c_id].view_list.contains(pl.ID()))
									{
										clients[c_id].view_list.insert(pl.ID());
										clients[c_id].vl.unlock();

										//put
										clients[c_id].send_put_packet(pl.ID());


										//���� ������� ������
										pl.vl.lock();
										if (!pl.view_list.contains(clients[c_id].ID()))
										{
											pl.view_list.insert(clients[c_id].ID());
											pl.vl.unlock();

											//put
											pl.send_put_packet(c_id);
										}
										else
										{
											pl.vl.unlock();

											//move
											pl.send_move_packet(c_id, 0);
										}
									}
									else // ������
									{
										clients[c_id].vl.unlock();

										//���� ������� ������
										pl.vl.lock();
										if (!pl.view_list.contains(clients[c_id].ID()))
										{
											pl.view_list.insert(clients[c_id].ID());
											pl.vl.unlock();

											//put
											pl.send_put_packet(c_id);
										}
										else
										{
											pl.vl.unlock();

											//move
											pl.send_move_packet(c_id, 0);
										}
									}
								}

								pl._sl.unlock();
							}
						}
					}

				}

				HeartManager::add_timer(c_id, 5000, EV_HEAL, c_id);
				break;
			}
			}
			break;
		}
		case OP_AI:
		{
			OVER_AI* ai_over = reinterpret_cast<OVER_AI*>(ex_over);

			switch (ai_over->_timer_type)
			{
			case TIMER_EVENT_TYPE::EV_ATTACK:
			{
				int npc_id = ai_over->object_id;
				//ó��

				for (int i = 0; i < 3; ++i)
				{
					for (int h = 0; h < 3; ++h)
					{
						if (clients[npc_id].sectorX - 1 + i < 0 ||
							clients[npc_id].sectorX - 1 + i >= W_WIDTH / SECTOR_WIDTH ||
							clients[npc_id].sectorY - 1 + h < 0 ||
							clients[npc_id].sectorY - 1 + h >= W_HEIGHT / SECTOR_HEIGHT)
							continue;

						for (auto& pln : sectors[clients[npc_id].sectorX - 1 + i][clients[npc_id].sectorY - 1 + h])
						{
							if (pln.second == false)
								continue;
							if (pln.first == npc_id)
								continue;

							auto& pl = clients[pln.first];
							if (pl.ID() >= MAX_USER) continue;

							int hitted = 0;

							pl._sl.lock();
							//cout << "Attemp ";
							if (abs(pl.getData().x - clients[npc_id].getData().x) +
								abs(pl.getData().y - clients[npc_id].getData().y) <= 2)
							{
								//�ǰ�
								hitted = clients[npc_id].getData().level + 1 + (rand() % 3);

								pl.setDamage(hitted);

							}

							if (hitted > 0)
							{
								//cout << "Att" << endl;
								string mess;
								mess = clients[npc_id].getData().name;
								mess += " attack ";
								mess += pl.getData().name;
								mess += " by ";
								mess += to_string(hitted);
								pl.send_chat_packet(-1, mess.c_str());

								pl.vl.lock();
								unordered_set<int> r_view_list = pl.view_list;
								pl.vl.unlock();

								pl.send_stat_change_packet(pln.first);
								for (auto& every : r_view_list)
								{
									if (!clients[every].getData().isPlayer)
										continue;

									clients[every].send_stat_change_packet(pln.first);
								}
							}
							else if (hitted < 0)
							{
								string mess;
								mess = pl.getData().name;
								mess += " collapsed!";

								clients[npc_id].ll.lock();
								lua_getglobal(clients[npc_id].L, "set_state");
								lua_pushnumber(clients[npc_id].L, 1);
								int error = lua_pcall(clients[npc_id].L, 1, 0, 0);
								if (error) {
									cout << "Error:" << lua_tostring(clients[npc_id].L, -1);
									lua_pop(clients[npc_id].L, 1);
								}
								clients[npc_id].ll.unlock();

								pl.vl.lock();
								unordered_set<int> r_view_list = pl.view_list;
								pl.vl.unlock();

								pl.send_chat_packet(-1, mess.c_str());
								pl.send_stat_change_packet(pln.first);
								for (auto& every : r_view_list)
								{
									if (!clients[every].getData().isPlayer)
										continue;

									clients[every].send_chat_packet(-1, mess.c_str());
									clients[every].send_stat_change_packet(pln.first);
									if (every != pln.first)
										clients[every].send_remove_packet(pln.first);
								}
							}
							pl._sl.unlock();
						}
					}
				}

				break;
			}
			case TIMER_EVENT_TYPE::EV_MOVE:
				HeartManager::move_npc(ai_over->object_id, ai_over->target_id);
				break;
			case TIMER_EVENT_TYPE::EV_HEAL:
				clients[ai_over->object_id]._sl.lock();
				clients[ai_over->object_id].autoHeal();
				for (auto& every : sectors[clients[ai_over->object_id].sectorX][clients[ai_over->object_id].sectorY])
				{
					if (every.second == false)
						continue;

					//cout << "\nSENDED";
					clients[every.first].send_stat_change_packet(ai_over->object_id);
				}
				clients[ai_over->object_id]._sl.unlock();
				HeartManager::add_timer(ai_over->object_id, 5000, EV_HEAL, ai_over->object_id);
				break;
			}
		}
		break;
		}

	}
}

int main()
{
	HeartManager::initialize_npc();

	WSADATA WSAData;
	WSAStartup(MAKEWORD(2, 2), &WSAData);

	g_s_socket = WSASocket(AF_INET, SOCK_STREAM, 0, NULL, 0, WSA_FLAG_OVERLAPPED);
	SOCKADDR_IN server_addr;

	memset(&server_addr, 0, sizeof(server_addr));
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(PORT_NUM);
	server_addr.sin_addr.S_un.S_addr = INADDR_ANY;

	bind(g_s_socket, reinterpret_cast<sockaddr*>(&server_addr), sizeof(server_addr));
	listen(g_s_socket, SOMAXCONN);

	SOCKADDR_IN cl_addr;
	int addr_size = sizeof(cl_addr);

	int client_id = 0;

	g_h_iocp = CreateIoCompletionPort(INVALID_HANDLE_VALUE, 0, 0, 0);
	CreateIoCompletionPort(reinterpret_cast<HANDLE>(g_s_socket), g_h_iocp, 9999, 0);
	SOCKET c_socket = WSASocket(AF_INET, SOCK_STREAM, 0, NULL, 0, WSA_FLAG_OVERLAPPED);
	OVER_EXP accept_over;
	accept_over._comp_type = OP_ACCEPT;
	accept_over._wsabuf.buf = reinterpret_cast<CHAR*>(c_socket);
	AcceptEx(g_s_socket, c_socket, accept_over._send_buf, 0, addr_size + 16, addr_size + 16, 0, &accept_over._over);

	s_Map::loadMap();

	vector <thread> worker_threads;

	//�̰� 1�� �ϸ� �̱� �������
	for (int i = 0; i < 6; i++)
	{
		worker_threads.emplace_back(do_worker);
	}
	thread db_thread{ DataBaseManager::DBThread };
	thread ai_thread{ HeartManager::ai_thread };

	db_thread.join();
	for (auto& th : worker_threads)
	{
		th.join();
	}



	closesocket(g_s_socket);
	WSACleanup();
}

