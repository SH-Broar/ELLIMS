#pragma once
#include "Turboc.h"

class c_Map {
public:
	static char c_basemap[W_WIDTH][W_HEIGHT];
	static void loadMap();
};



